package com.lb.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LbGeneratorDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LbGeneratorDemoApplication.class, args);
    }

}
