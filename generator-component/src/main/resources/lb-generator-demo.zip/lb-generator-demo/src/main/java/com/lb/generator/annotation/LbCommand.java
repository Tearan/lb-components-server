package com.lb.generator.annotation;

import java.lang.annotation.*;

/**
 * @ClassName LbCommand
 * @Description 命令
 * @Author Terran
 * @Date 2021/3/18 11:01
 * @Version 1.0
 */

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface LbCommand {

    /**
     * 命令名，不提供默认方法名
     * @return
     */
    String name() default "";
}
