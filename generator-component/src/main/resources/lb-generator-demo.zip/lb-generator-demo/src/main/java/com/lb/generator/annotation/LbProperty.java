package com.lb.generator.annotation;

import java.lang.annotation.*;

/**
 * @ClassName LbProperty
 * @Description 属性
 * @Author Terran
 * @Date 2021/3/18 10:51
 * @Version 1.0
 */

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface LbProperty {

    /**
     * 属性是否可写。注：所有属性默认都可读
     * @return
     */
    boolean writeable() default true;

    /**
     * 属性名,不提供默认字段名
     * @return
     */
    String name() default "";
}
